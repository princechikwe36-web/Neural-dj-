import asyncio
import os
import re
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

ROOT = Path(os.getenv("NEURAL_DJ_DATA", "/tmp/neural-dj"))
INPUTS, JOBS = ROOT / "inputs", ROOT / "jobs"
for folder in (INPUTS, JOBS):
    folder.mkdir(parents=True, exist_ok=True)

MAX_MB = int(os.getenv("MAX_UPLOAD_MB", "100"))
MODEL = os.getenv("DEMUCS_MODEL", "htdemucs")
SHIFTS = os.getenv("DEMUCS_SHIFTS", "1")
API_KEY = os.getenv("NEURAL_DJ_API_KEY", "").strip()
STEMS = ("drums", "vocals", "bass", "other")
GPU_LOCK = asyncio.Semaphore(int(os.getenv("MAX_PARALLEL_JOBS", "1")))

app = FastAPI(title="Neural DJ AI Stem Server", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "X-API-Key"],
)

def check_key(x_api_key: str | None):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid AI server API key")

def run_demucs(input_path: Path, output_path: Path):
    cmd = [
        sys.executable, "-m", "demucs", "-n", MODEL,
        "--shifts", SHIFTS, "--float32", "--out", str(output_path),
        str(input_path),
    ]
    result = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=int(os.getenv("DEMUCS_TIMEOUT_SECONDS", "3600"))
    )
    if result.returncode != 0:
        raise RuntimeError((result.stdout or "Demucs failed")[-5000:])
    found = {}
    for stem in STEMS:
        matches = list(output_path.rglob(stem + ".wav"))
        if not matches:
            raise RuntimeError(f"Demucs did not create {stem}.wav")
        found[stem] = matches[0]
    return found

@app.get("/health")
def health():
    try:
        import torch
        gpu = torch.cuda.is_available()
        device = torch.cuda.get_device_name(0) if gpu else "CPU"
    except Exception:
        gpu, device = False, "unknown"
    return {"ok": True, "model": MODEL, "gpu": gpu, "device": device}

@app.post("/api/separate")
async def separate(file: UploadFile = File(...), x_api_key: str | None = Header(default=None)):
    check_key(x_api_key)
    filename = Path(file.filename or "track.audio").name
    suffix = Path(filename).suffix.lower()
    if suffix not in {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".opus"}:
        raise HTTPException(status_code=415, detail="Use MP3, WAV, FLAC, M4A, AAC, OGG or OPUS audio")
    data = await file.read((MAX_MB * 1024 * 1024) + 1)
    if not data:
        raise HTTPException(status_code=400, detail="The uploaded audio file is empty")
    if len(data) > MAX_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"Maximum upload size is {MAX_MB} MB")

    job_id = uuid.uuid4().hex
    in_dir, out_dir = INPUTS / job_id, JOBS / job_id
    in_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    input_path = in_dir / ("source" + suffix)
    input_path.write_bytes(data)
    try:
        async with GPU_LOCK:
            found = await asyncio.to_thread(run_demucs, input_path, out_dir / "demucs")
        for stem, path in found.items():
            shutil.copyfile(path, out_dir / f"{stem}.wav")
        return {
            "job_id": job_id,
            "model": MODEL,
            "stems": {stem: f"/api/jobs/{job_id}/{stem}.wav" for stem in STEMS},
        }
    except subprocess.TimeoutExpired:
        shutil.rmtree(out_dir, ignore_errors=True)
        raise HTTPException(status_code=504, detail="AI separation timed out; try a shorter audio file")
    except Exception as exc:
        shutil.rmtree(out_dir, ignore_errors=True)
        raise HTTPException(status_code=500, detail=f"AI separation failed: {str(exc)[-1200:]}")
    finally:
        shutil.rmtree(in_dir, ignore_errors=True)

@app.get("/api/jobs/{job_id}/{stem_file}")
def get_stem(job_id: str, stem_file: str, x_api_key: str | None = Header(default=None)):
    check_key(x_api_key)
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        raise HTTPException(status_code=404, detail="Job not found")
    if stem_file not in {f"{s}.wav" for s in STEMS}:
        raise HTTPException(status_code=404, detail="Stem not found")
    path = JOBS / job_id / stem_file
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Stem file expired or not found")
    return FileResponse(path, media_type="audio/wav", filename=stem_file, headers={"Cache-Control": "no-store"})

# Neural DJ — Heavy AI Stem Server

This is the separate GPU backend for the Neural DJ HTML app. It uses **Demucs HTDemucs** to separate a full song into four real AI-generated WAV stems:

- `drums.wav`
- `vocals.wav`
- `bass.wav`
- `other.wav` (shown as **Harmonic** in the DJ app)

The browser app remains hosted on GitHub Pages. This server must run separately on a GPU-capable host. GitHub Pages cannot run the Demucs model.

## 1. Build and run on a GPU server

Upload this folder to a GPU server with Docker and NVIDIA Container Toolkit available, then run:

```bash
docker build -t neural-dj-demucs .
docker run --gpus all -p 8000:8000 \
  -e NEURAL_DJ_API_KEY="choose-a-long-private-key" \
  -e MAX_UPLOAD_MB=100 \
  --name neural-dj-demucs neural-dj-demucs
```

The host must expose TCP port `8000` over HTTPS. Use the public HTTPS base URL provided by your GPU host, without a trailing slash.

Check that the server is ready:

```text
https://YOUR-GPU-SERVER/health
```

A healthy GPU deployment reports `"gpu": true` and the GPU device name. CPU fallback is supported but can be very slow.

## 2. Connect the GitHub Pages app

1. Replace your repository's `index.html` with `index-stem-ai.html` (rename it to `index.html`).
2. Open the app and load an audio track into Deck A or Deck B.
3. Open that deck's **AI** panel, then **STEM MIX**.
4. Tap **CONNECT AI SERVER** and paste your GPU server's HTTPS base URL.
5. If you enabled `NEURAL_DJ_API_KEY`, save the same key in browser storage as `neuralDJ_AI_key` (see below).
6. Tap **SEPARATE WITH AI** and wait for all four stems to download.

### Save the API key in the browser

Open the browser developer console where available and run:

```js
localStorage.setItem("neuralDJ_AI_key", "YOUR_PRIVATE_KEY");
```

If your GPU host does not require an API key, leave this blank.

## 3. Settings

- `DEMUCS_MODEL=htdemucs` selects the Hybrid Transformer Demucs model.
- `DEMUCS_SHIFTS=1` is the default inference setting. Set to `2` for slower, higher-quality inference.
- `MAX_UPLOAD_MB=100` limits uploaded file size.
- `MAX_PARALLEL_JOBS=1` prevents multiple heavy GPU jobs from overloading the server.
- `NEURAL_DJ_API_KEY` enables a simple shared-key check. Keep the key private.

## Notes

- The four separated stems are rendered from the same Demucs separation and start at the same deck position and playback rate.
- Beat Sync continues to use the original full mix for BPM/beat-grid analysis, then the same tempo and seek corrections apply to all four stems together.
- **Harmonic** is the app's label for Demucs' `other` stem. It contains accompaniment and other non-vocal/non-drum/non-bass material; it is not a perfect isolated chord track.
- This server returns full WAV stems, so downloads can be large and separation takes time. A GPU is strongly recommended.
- Use audio files you have permission to process. Do not expose an unauthenticated public server to the open internet; set an API key and use HTTPS.
